"""Command-line validation helpers."""
