"""Bank worker service."""
