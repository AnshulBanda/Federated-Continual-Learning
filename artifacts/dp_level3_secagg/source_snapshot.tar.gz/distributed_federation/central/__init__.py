"""Central aggregation service."""
